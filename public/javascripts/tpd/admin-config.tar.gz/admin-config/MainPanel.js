/*
 * Ext JS Library 2.0.1
 * Copyright(c) 2006-2008, Ext JS, LLC.
 * licensing@extjs.com
 * 
 * http://extjs.com/license
 */

MainPanel = function(){
    this.User = Ext.data.Record.create([
        {name: 'firstname', type: 'string'},
        {name: 'lastname', type: 'string'},
        {name: 'email', type: 'string'},
        {name: 'usergroup', type: 'string'},
        {name: 'active', type: 'string'},
    ]);

    this.search_store = new Ext.data.Store({
        // load using HTTP
        proxy: new Ext.data.HttpProxy({
              url: '/users.xml',
              method: 'GET'
        }),

        // the return will be XML, so lets set up a reader
        reader: new Ext.data.XmlReader({
              record: 'product',
              id: 'id'
           }, this.User),

        sortInfo:{field:'name', direction:'DESC'}
    });

    this.user_store = new Ext.data.Store({
        // load using HTTP
        proxy: new Ext.data.HttpProxy({
              url: '/users.xml',
              method: 'GET'
        }),

        // the return will be XML, so lets set up a reader
        reader: new Ext.data.XmlReader({
              record: 'user',
              id: 'id'
           }, this.User),

        sortInfo:{field:'name', direction:'DESC'}
    });

    this.search_sm = new Ext.grid.CheckboxSelectionModel({singleSelect:true});

    this.search_cm = new Ext.grid.ColumnModel([
        this.search_sm,
        {
           id:'name',
           header: "Name",
           dataIndex: 'name',
           width: 400
        },{
           header: "Model",
           dataIndex: 'model',
           width: 100
        }
    ]);


    this.preview = new Ext.grid.EditorGridPanel({
        cm: this.search_cm,
        sm: this.search_sm,
        store: this.search_store,
        id: 'preview',
        region: 'south',
        cls:'preview',
        autoScroll: true,
//        listeners: FeedViewer.LinkInterceptor,

        viewConfig: {
            forceFit:true
        },

        tbar: [
           'Search for products: ',
            new Ext.app.SearchField({
                store: this.search_store,
                 width:200
            }),
              
        {
            id:'add',
            text: 'Add selected to this Kit',
            iconCls: 'new-tab',
            disabled:true,
            handler : this.openTab,
            scope: this
        },
        '-',
        {
            id:'copy',
            text: 'Copy this Kit to selected',
            iconCls: 'new-win',
            disabled:true,
            scope: this,
            handler : function(){
                window.open(this.gsm.getSelected().data.link);
            }
        }

        ],

/*        clear: function(){
            this.body.update('');
            var items = this.topToolbar.items;
            items.get('add').disable();
            items.get('copy').disable();
        } */
    });

    this.grid = new FeedGrid(this, {
        tbar:[
        ]
    });

    MainPanel.superclass.constructor.call(this, {
        id:'main-tabs',
        activeTab:0,
        region:'center',
        margins:'0 5 5 0',
        resizeTabs:true,
        tabWidth:150,
        minTabWidth: 120,
        enableTabScroll: true,
//        plugins: new Ext.ux.TabCloseMenu(),
        items: {
            id:'main-view',
            layout:'border',
            title:'Loading...',
            hideMode:'offsets',
            items:[
                this.grid, {
                id:'bottom-preview',
                layout:'fit',
                items:this.preview,
                height: 150,
                split: true,
                border:false,
                region:'south'
            }
             ]
        }
    });
};

Ext.extend(MainPanel, Ext.TabPanel, {

    loadFeed : function(feed){
        this.grid.loadFeed(feed.url);
        Ext.getCmp('main-view').setTitle(feed.text);
    }
});